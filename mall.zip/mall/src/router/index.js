import Vue from 'vue'
import Router from 'vue-router'
import Home from '@/components/Home'
import Side from '@/components/Side'
import Login from '@/components/Login'
import Register from '@/components/Register'
import GoodDetail from '@/components/GoodDetail'
import Goodcar from '@/components/Goodcar'
import Buy from '@/components/Buy'
import BuySuccess from '@/components/BuySuccess'

Vue.use(Router)
export default new Router({
  routes: [
    {
      path: '/',
      name: 'Home',
      component: Home
    },
    {
      path: '/side',
      name: 'side',
      component: Side
    },
    {
      path: '/login',
      name: 'login',
      component: Login
    },
    {
      path: '/register',
      name: 'register',
      component: Register
    },
    {
      path: '/GoodDetail:id',
      component: GoodDetail
    },
    {
      path:'/Goodcar',
      component:Goodcar
    },
    {
      path:'/Buy',
      component:Buy
    },
    {
      path:'/BuySuccess',
      component:BuySuccess
    }
    
    
  ]
})
