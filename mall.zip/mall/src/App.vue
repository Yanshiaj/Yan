<template>
  <div id="app">
    <!--Container布局容器-->
    <el-container class="hcontain">
      <!--头部区域-->
      <el-header height="60px">
       <img class="im" src="./assets/img/logo.jpg" />
        <div class="spanbd">
          <a ><router-link to="/">首页</router-link></a>
          <a href="#">所有商品</a>
          <a href="#">活动和特惠</a>
          <a href="#">服务</a>
          <a href="#">家居灵感</a>
          <a href="#">新品</a>
          <a href="#">宜家对公业务</a>
        </div>
        <div class="lheader">
        <span ><router-link to="/login">登录</router-link></span>
        <span>|</span>
        <span ><router-link to="/register">注册</router-link></span>
        </div>
        <i class="el-icon-shopping-cart-full"></i>
        <font ><router-link to="/Goodcar">购物车</router-link></font>
      
       <el-input class="sear" placeholder="你在找什么？" suffix-icon="el-icon-search" v-model="input1"></el-input>
      </el-header>
      <router-view/>   <!--路由占位符-->
      <div id="contain">
        </div>

      <!--尾部-->
      <el-footer>Z09418240</el-footer>
    </el-container>
   
  </div>
</template>

<script>
import Home from './components/Home';

export default {
  name: "App",
  data() {
    return {
      input1: '',
    }
  },
  components: {
     //运用组件
     Home
  },
  methods:{
    lheader(){
        let flag = false
        this.users.forEach(element => {
            if (element.username === this.loginForm.username && element.password === this.loginForm.password) {
                flag = true
                // break;
            }
        });
        if (flag) {
            alert('登陆成功')
            localStorage.setItem('loginUser', JSON.stringify(this.loginForm))
            this.$router.push('/home')
        } else {
            alert('登陆失败')
        }
    },
  }
};
</script>

<style>
#app {
  font-family: "Avenir", Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}
.im{
  width:120px;
  height:50px;
  margin-top:3px;
  margin-left:-175px;
}
.hcontaincon {
  height: 1200px;
}
.el-header {
  background-color: black;
  text-align: center;
  display: flex;
  justify-content: space-between;
}
.el-header img{
  height:58px;
  width: 100px;
  position: absolute;
  top: -2px;
  left:170px;
}
.el-footer {
  background-color:black;
  color:lightgray;
  text-align: center;
  line-height: 60px;
}
a {
  font-size: 14px;
  color: white;
  margin-left: 8px;
  text-decoration: none;
}
a:hover {
  color: grey; /* 鼠标移入变色 */
}
.spanbd {
  width: 1000px;
  height:20px;
  margin:auto;
  margin-left:80px;
}
.lheader{
  width:400px;
  margin:auto;
  height:20px;
  margin-left:-100px;
  

}
span{
  margin:auto;
  font-size: 14px;
  color:rgb(250, 243, 243);
  margin-left:10px;
  text-decoration: none;
}

span:hover {
  color:white; 
}
font{
  margin:auto;
  width: 130px;
  font-size: 14px;
  color:white;
  margin-right:100px;
  text-decoration: none;
  
}
font:hover {
  color: grey;
}

.el-icon-shopping-cart-full{
  margin:auto;
  color: white;
  width:150px;
}
.sear{
  width:250px;
  height:30px;
  margin:auto;
}
#contain{
  height:1020px;
}
</style>
