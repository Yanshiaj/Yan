<template>
    <div class="goodShowContain">
    <div class="bottomText">
      <span class="bottomTextLine">——————</span>
      <span class="bottomTextContent">商品展示</span>
      <span class="bottomTextLine">——————</span>
    </div>
        <SingleGood v-for="item in 50" :key="item" :goodid="item"></SingleGood>
    </div>
</template>

<script>
import SingleGood from './singleGood.vue'
export default {
    components:{
        SingleGood
    }
}
</script>
<style scoped>

.goodShowContain{
    width:1300px;
    height: 3250px;
    margin-top: 500px;
    margin-left:-1215px;
    display: inline-block;
    background-color:white;
    
}
.bottomText{
    /* background-color: tomato; */
    height: 60px;
    line-height: 60px;
}
.bottomTextContent{
    font-size: 20px;
    /* font-weight: 600; */
    color: rgba(143, 145, 149, 0.9);
    
}
.bottomTextLine{
    position: relative;
    top: -3px;
    color: #777777;
    opacity: 0.3;
}
</style>
