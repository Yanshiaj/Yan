<template>
    <div class="singleGoodContain">
        <div class="singleGoodContainContent">
            <router-link :to="geturl()">
                <img :src="this.gooditem.pic1" alt="">
            </router-link>
            <p>{{this.gooditem.title}}</p>
             <p>{{this.gooditem.price}}</p><!--差值表达式-->
        </div>
    </div>
</template>

<script>
export default {
    props:["goodid"],
    data(){
        return {
            gooditem:"",
        }
    },
created(){
    this.init()
  },
  methods:{
    geturl(){
        return "/GoodDetail"+(this.goodid-1);
    },
    init(){
      // 获取本地JSON文件
       axios.get("static/goodlist.json").then((res)=>{
        this.gooditem = res.data.goods[this.goodid-1];
      })
    }
  }
}
</script>

<style scoped>
.singleGoodContain{

    width: 230px;
    height: 300px;
    margin-right: 10px;
    margin-bottom: 10px;
    display: inline-block;
    background-color: white;
}
.singleGoodContainContent img {
    width: 220px;
    height: 220px;
}

</style>

