<!--Container布局容器-->
<template>
<div class="bb">
  <el-container>
    <div class="main_box">
      <el-container class="hcontain" >
        <el-aside width="200px"><Side /> </el-aside>
        <el-main>
          <Nav />
        </el-main> 
      </el-container>
    </div>

      <GoodShow/>

       
  </el-container>
  <div class="aa">
  <img src="../assets/img/dibu.jpg">
  </div>
</div>
</template>

<script>
import Nav from "../components/Nav"; //引入轮播组件
import Side from "../components/Side";
import GoodShow from "../components/GoodShow";

export default {
  name: "Home",
  components: {
    Nav,
    Side,
    GoodShow

  },
  methods: {
    logout() {
      window.sessionStorage.clear();
      this.$router.push("/login");
    },
  },
};
</script>
<style scoped>
.aa img{
  width:1200px;
}
.bb{
  height:3200px;
  width: 1263px;
  /* background-color: turquoise; */
}
.main_box{
  width: 1300px;
  height:490px;
  position: relative;
  /* background-color: sienna; */
  /* background-color: seagreen; */
}
</style>
