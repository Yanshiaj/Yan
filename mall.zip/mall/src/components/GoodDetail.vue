<template>
    <div class="container">
        <div class="cl1">
            <div class="loupe">
                <vue-photo-zoom-pro :url="gooditem.pic1"></vue-photo-zoom-pro>
            </div>
            <div class="cl2">
                <span>{{this.gooditem.title}}</span>
                <p>
                    <span>{{this.gooditem.price}}</span>
                </p>
                <p>
                    <span>{{this.gooditem.detail}}</span>
                </p>
                <div class="p1"><span class="f1">快递配送：</span> 16：00前付款，承诺当日发货，次日达</div>
                <!-- <el-button type="info" plain>信息按钮</el-button> -->
                <div class="xuanzeguige">
                    <span class="f1">选择规格：</span>
                    <el-button type="info">官方标配</el-button>
                </div>
                <div class="number">
                    <span class="f1">数量:</span>
                    <button @click="sub()">-</button>
                    {{ count }}
                    <button @click="add()">+</button>
                </div>
                <button class="btn btn-info" @click="handleAddCart()">加入购物车</button>

            </div>
        </div>
    </div>
</template>

<script>
export default {
    props: ["gid"],
    created(){
        axios.get("static/goodlist.json").then((res)=>{
            // console.log(this.$route.params.id);
         this.gooditem = res.data.goods[this.$route.params.id];
         console.log(this.gooditem);
        })
    },
    data(){
        return{
           id: this.$route.params.id, //获取id
      gooditem: "",
      form: {
        name: "",
        region: "",
        desc: "",
      },
      goodsList: [],
      carts: [],
      count: 1,
    };
        

    },
    methods:{
        gettitle(){
            if(this.gooditem!=""){
                return this.gooditem;
            }
        },
        getprice(){
            if(this.gooditem!=""){
                return this.gooditem.price;
            }
        },
        getdetail(){
            if(this.gooditem!=""){
                return this.gooditem.color;
            }
        },
       
         getGood() {
      let goods = JSON.parse(localStorage.getItem("goods"));
      let good;
      goods.forEach((item) => {
        if (item["gid"] == this.$route.params.id) {
          good = item;
          localStorage.setItem("shoppingcar", JSON.stringify(item["gid"]));
        }
      });
      return good;
    },
    handleAddCart()  {
      console.log(this.getGood());

      let goods = this.getGood();
      goods["count"] = this.count;

      console.log(goods);

      
      if (localStorage.getItem("carts") === null) {
        this.$axios({
          url: "/static/d-goods.json",
        }).then((res) => {
          let data = res.data;
         
          data.push(goods);
          localStorage.setItem("carts", JSON.stringify(data));
        });
      } else {
        let carts = JSON.parse(localStorage.getItem("carts"));
        
        carts.push(goods);
        localStorage.setItem("carts", JSON.stringify(carts));
      }
      this.$router.push("/GoodCar");
    },

    add() {
      this.count++;
    },
    sub() {
      if (this.count !== 1) {
        this.count--;
      }
    },
  },
  computed: {
    getGoodsList() {
      return this.goodsList;
    },
  },
  beforeCreate() {
    this.$axios({
      url: "/static/goodlist.json",
    })
      .then((res) => {
        console.log(res.data);
        localStorage.setItem("goods", JSON.stringify(res.data.goods));
        this.goodsList = res.data.goods;
      })
      .catch((err) => {
        console.log(err);
      });
  },
  mounted() {
    this.$router.afterEach((to, from, next) => {
      window.scrollTo(0, 0);
    });

    }
}
</script>


<style scoped>
.container {
    width: 1200px;
    margin: 0 auto;
    /* display: felx; */
    /* justify-content: center;
    align-content: center; */
}
.loupe{
    height: 500px;
    width: 500px;
    display: inline-block;

    margin-top: 50px;
    display: inline-block;
    background-color:white;
}
.cl2 {   
    
    align-content: center;
    background-color: white;
    display: inline-block;
    height: 200x;
    padding: 80px 50px;
   
    
}
.cl1
{
   /* height: 100%; */
   display: flex;
    justify-content: center;
    align-content: center;
}

span{
    color:black;
    font-size:20px;
    

   
}
.f1 {
    color:gray;
}

.xuanzeguige{
    margin-top: 15px;
    margin-left: -170px;
}
.number{
    margin-top: 15px;
    margin-left: -260px;
}
.btn{
    height:30px;
    margin-left:-200px;
    margin-top:60px;
}


</style>