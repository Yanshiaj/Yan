<template>
  <div class="slide" v-on:mouseover="stop()" v-on:mouseout="move()">
    <div class="slideshow">
      <transition-group tag="ul" name="image">
        <li v-for="(img, index) in imgArray" v-show="index===mark" :key="img">
          <a href="#">
            <img :src='img'>
          </a>
        </li>
      </transition-group>
    </div>
    <div class="bar">
      <span v-for="(item, index) in imgArray" :class="{ 'active':index===mark }"
      @click="change(index)" :key="index"></span>
    </div>
    <div class="du">
      
    常用品牌
   
      </div>
  </div>
</template>
 
<script>
export default {
  data () {
    return {
      timer: null, //定时器
      mark: 0, //比对图片索引的变量
      imgArray: [require("../assets/img/lunbo1.jpg"),
                 require("../assets/img/lunbo2.jpg"),
                 require("../assets/img/lunbo3.jpg"),
                 require("../assets/img/lunbo4.jpg"),
      ]
    }
  },
  methods: {
    autoPlay () {
      this.mark++;
      if (this.mark === 4) {  //当遍历到最后一张图片置0
        this.mark = 0
      }
    },
    play () {
      this.timer = setInterval(this.autoPlay, 1500)
    },
    change (i) {
      this.mark = i
    },
    stop () {
      clearInterval(this.timer)
    },
    move () {
      this.timer = setInterval(this.autoPlay, 2500)
    }
  },
  created () {
    this.play()
  }
}
</script>



<style scoped>
  * {
    margin: 0;
    padding: 0;
    list-style: none;
  }
  .slide {
    width: 1000px;
    height: 400px;
    margin: 0 auto;
    margin-top: 50px;
    overflow: hidden;
    position: relative;
    
  }
  .slideshow {
    width: 1024px;
    height: 1500px;
    display: inline;
    
  }
  li {
    position: absolute;
    margin:  0 auto;
  }
  img {
    width: 780px;
    height: 300px;
    position:absolute;
   
  }
  .bar {
    position: absolute;
    width: 100%;
    bottom: 40px;
    margin: 0 auto;
    z-index: 10;
    text-align: center;
    left:-95px;
  }
  .bar span {
    width: 20px;
    height: 5px;
    border: 1px solid;
    background:grey;
    display: inline-block;
    margin-right: 10px;
  }
  .active {
    background:black !important;
  }
  

</style>