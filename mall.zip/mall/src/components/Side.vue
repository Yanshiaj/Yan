<!--侧边导航栏--><!--mode="horizontal"模式调用水平-->
<template>
  <el-menu mode="horizontal" @select="handleSelect" background-color="white" text-color="black" active-text-color="black">
    <el-submenu index="1">
      <template slot="title" >所有商品</template>
      <el-submenu index="1-1">
        <template slot="title">房间</template>
        <el-menu-item href="#" index="1-1-1">卧室</el-menu-item>
        <el-menu-item href="#" index="1-1-2">客厅</el-menu-item>
        <el-menu-item href="#" index="1-1-3">厨房</el-menu-item>
        <el-menu-item href="#" index="1-1-3">餐厅</el-menu-item>
        <el-menu-item href="#" index="1-1-3">儿童房</el-menu-item>
      </el-submenu>
      <el-submenu index="1-2">
        <template slot="title">家具</template>
        <el-menu-item href="#" index="1-2-1">沙发</el-menu-item>
        <el-menu-item href="#" index="1-2-2">床</el-menu-item>
        <el-menu-item href="#" index="1-2-3">衣柜</el-menu-item>
        <el-menu-item href="#" index="1-1-3">椅子</el-menu-item>
        <el-menu-item href="#" index="1-1-3">电视和多媒体家具</el-menu-item>
      </el-submenu>
      <el-submenu index="1-3">
        <template slot="title">灯具照明</template>
        <el-menu-item href="#" index="1-3-1">LED照明灯泡</el-menu-item>
        <el-menu-item href="#" index="1-3-2">装饰性灯具</el-menu-item>
        <el-menu-item href="#" index="1-4-3">智能照明</el-menu-item>
        <el-menu-item href="#" index="1-1-3">内置灯具</el-menu-item>
        <el-menu-item href="#" index="1-1-3">户外照明</el-menu-item>
      </el-submenu>
      <el-submenu index="1-4">
        <template slot="title">床和床垫</template>
        <el-menu-item href="#" index="1-4-1">床</el-menu-item>
        <el-menu-item href="#" index="1-4-2">床垫</el-menu-item>
        <el-menu-item href="#" index="1-4-3">卧室纺织品</el-menu-item>
        <el-menu-item href="#" index="1-1-3">床底收纳</el-menu-item>
        <el-menu-item href="#" index="1-1-3">床头柜</el-menu-item>
      </el-submenu>
      <el-submenu index="1-5">
        <template slot="title">储物和收纳</template>
        <el-menu-item href="#" index="1-5-1">衣柜</el-menu-item>
        <el-menu-item href="#" index="1-5-2">电视和多媒体家具</el-menu-item>
        <el-menu-item href="#" index="1-5-3">书柜和置物架</el-menu-item>
        <el-menu-item href="#" index="1-1-3">橱柜和展示柜</el-menu-item>
        <el-menu-item href="#" index="1-1-3">抽屉和抽屉框架</el-menu-item>
      </el-submenu>
      <el-submenu index="1-6">
        <template slot="title">橱柜和家电</template>
        <el-menu-item href="#" index="1-6-1">厨房橱柜系列</el-menu-item>
        <el-menu-item href="#" index="1-6-2">墙面板</el-menu-item>
        <el-menu-item href="#" index="1-6-3">内部配件</el-menu-item>
        <el-menu-item href="#" index="1-1-3">厨房水龙头和水槽</el-menu-item>
        <el-menu-item href="#" index="1-1-3">厨房电器</el-menu-item>
      </el-submenu>
      <el-submenu index="1-7">
        <template slot="title">纺织品</template>
        <el-menu-item href="#" index="1-7-1">卧室纺织品</el-menu-item>
        <el-menu-item href="#" index="1-7-2">窗帘和卷帘</el-menu-item>
        <el-menu-item href="#" index="1-7-3">靠垫和靠垫套</el-menu-item>
        <el-menu-item href="#" index="1-1-3">浴室纺织品</el-menu-item>
        <el-menu-item href="#" index="1-1-3">婴儿纺织品</el-menu-item>
      </el-submenu>
      <el-submenu index="1-8">
        <template slot="title">装饰品</template>
        <el-menu-item href="#" index="1-8-1">花盆</el-menu-item>
        <el-menu-item href="#" index="1-8-2">蜡烛和灯台</el-menu-item>
        <el-menu-item href="#" index="1-8-3">图片和框架</el-menu-item>
        <el-menu-item href="#" index="1-1-3">镜子</el-menu-item>
        <el-menu-item href="#" index="1-1-3">花瓶和碗</el-menu-item>
      </el-submenu>
      <el-submenu index="1-9">
        <template slot="title">灯具照明</template>
        <el-menu-item href="#" index="1-3-1">LED照明灯泡</el-menu-item>
        <el-menu-item href="#" index="1-3-2">装饰性灯具</el-menu-item>
        <el-menu-item href="#" index="1-4-3">智能照明</el-menu-item>
        <el-menu-item href="#" index="1-1-3">内置灯具</el-menu-item>
        <el-menu-item href="#" index="1-1-3">户外照明</el-menu-item>
      </el-submenu>
      <el-submenu index="1-10">
        <template slot="title">其他</template>
     </el-submenu>
    </el-submenu>
  </el-menu>
</template>
<script>
export default {
  //handleSelect方法点击触发选项事件，@select="handleSelect"调用方法
  methods: {
    handleSelect(key, keyPath) {
      console.log(key, keyPath);
    },
  },
};
</script>

<style scoped>

</style>
