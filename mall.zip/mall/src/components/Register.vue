
<template>
    <div class="register-wrapper">
        <div class="register">
            <!--头像区域-->
            <div class="avatar_box">
               <img src="../assets/img/头像.jpg" >
            </div>
            <!--注册表单区-->
            <el-form ref="registerFrom" :model="registerForm" :rules="registerFormRules"  label-width="0px" class="register_form">
                <!--设置用户名-->
             <el-form-item prop="username" >
             <el-input v-model="registerForm.username" id="username" placeholder="请输入用户名"></el-input>
             </el-form-item> 
            <!--设置密码-->
             <el-form-item prop="password" >
             <el-input  v-model="registerForm.password" id="userpassword" type="password" placeholder="请输入密码"></el-input>
             </el-form-item> 
             <!--确认密码-->
             <el-form-item prop="checkpassword" >
             <el-input  v-model="registerForm.checkpassword"  type="password" placeholder="请确认密码"></el-input>
             </el-form-item> 
             <!--按钮区域-->
             <el-form-item class="btns" >
               <el-button  type="primary" @click="submitForm">注册</el-button>
                <p class="login" @click="gotoLogin()">已有账号？立即登录</p>
             </el-form-item> 
            </el-form>
    </div>
    </div>
</template>

<script>
export default {
    data()
    {   
        return{
            //这是登录表单的数据绑定
            registerForm:{
                username: '',
                password:'',
                checkpassword:''

            },
            //表单验证规则对象
            registerFormRules:{
                //验证用户名是否合法
                username:[
                    {required:true,message:"请输入用户名", trigger:"blur"},
                    {min: 3, max: 10, message: '长度在 3 到 10个字符', trigger: 'blur' }
                ],
                //验证密码是否合法
                password:[
                    {required:true,message:"请输入密码", trigger:"blur"},
                    {min: 6, max: 15, message: '长度在 6 到 15个字符', trigger: 'blur' }
                ],
                checkpassword:[
                    {required:true,message:"请确认密码", trigger:"blur"},
                    {min: 6, max: 15, message: '长度在 6 到 15个字符', trigger: 'blur' }
                ],
            }
        }
        // <!--验证密码-->
    let validatePass = (rule, value, callback) => {
      if (value === "") {
        callback(new Error("请输入密码"))
      } else {
        if (this.ruleForm2.checkPass !== "") {
          this.$refs.ruleForm2.validateField("checkPass");
        }
        callback()
      }
    }
    // <!--二次验证密码-->
    let validatePass2 = (rule, value, callback) => {
      if (value === "") {
        callback(new Error("请再次输入密码"));
      } else if (value !== this.ruleForm2.pass) {
        callback(new Error("两次输入密码不一致!"));
      } else {
        callback();
      }
    };

    },
    methods:{
      //<!--提交注册-->  
     submitForm() {
         if ( this.registerForm.username.length < 3) {
             alert('用户名不能小于3位')
         } else if (this.registerForm.password >= 6 && this.registerForm.password <= 15) {
             alert('密码长度范围6-15')
         } else {
             if (this.registerForm.password !== this.registerForm.checkpassword) {
                alert('两次输入密码不一致')
             } else {
                 let arr = JSON.parse(window.localStorage.getItem('users'));
                 let i;
                 for(i=0;i<arr.length;i++){
                   if(arr[i].username===this.registerForm.username){
                     alert('该用户名已被注册');
                     return false;
                   }
                 }
                 arr.push(this.registerForm)
                 localStorage.setItem('users', JSON.stringify(arr))
                  alert('注册成功');
                 this.$router.push('/login')
             }
         }
    },
   //<!--进入登录页面-->
    gotoLogin() {
      this.$router.push({
        path: "/login"
      });
    },
} 
}
  

</script>

<style scoped >  
.register-wrapper{
    background-color: lightblue;
    height: 3000px;
}
.register{
    background-color: white;
    width:450px;
    height:400px;
    border-radius:3px;
    position:absolute;
    left:50%;
    top:350px;
    transform: translate(-50%,-50%);
}
.avatar_box{
    height:130px;
    width:130px;
    border:1px solid white;
    border-radius:50%;
    padding:10px;
    box-sizing:  0 0 10px  #ddd;
    position: absolute;
    left:50%;
    transform:translate(-50%,-50%);
    background-color: white;
}
.avatar_box img{
    position: absolute;
    left:0px;
    height: 120px;
    width: 140px;
}



 img{
    height:100%;
    width:100%;
    border-radius:50%;
    padding:10px;
    margin-left: -10px;
    margin-top: -15px;
    background-color:#eee;
}


.register_form{
    position: absolute;
    bottom:0;
    width:100%;
    padding: 0 20px;
    box-sizing: border-box;
}
.btns{
    display:flex;
    justify-content:center;
}


</style>