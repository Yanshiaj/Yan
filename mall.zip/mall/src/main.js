// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App.vue'
import router from './router'
import axios from 'axios'
import VuePhotoZoomPro from 'vue-photo-zoom-pro'
//导入全局样式表
import './assets/css/global.css'
//引入element-ui
import ElementUI from 'element-ui'
import {Form,FormItem} from 'element-ui'
import { Input} from 'element-ui'
import 'element-ui/lib/theme-chalk/index.css'

//使用element-uiUI 全局注册组件
Vue.use(ElementUI)
Vue.use(Form)
Vue.use(FormItem)
Vue.use(Input)
Vue.use(VuePhotoZoomPro)
Vue.prototype.$axios = axios

/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  components: { App },
  template: '<App/>'
})
